#pragma once

#include "aidl/com/luxoft/gpio/IGpioService.h"

#include <android/binder_ibinder.h>

namespace aidl {
namespace com {
namespace luxoft {
namespace gpio {
class BpGpioService : public ::ndk::BpCInterface<IGpioService> {
public:
  BpGpioService(const ::ndk::SpAIBinder& binder);
  virtual ~BpGpioService();

  ::ndk::ScopedAStatus setGpioState(int32_t in_pin, bool in_value, bool* _aidl_return) override;
  ::ndk::ScopedAStatus getGpioState(int32_t in_pin, bool* _aidl_return) override;
};
}  // namespace gpio
}  // namespace luxoft
}  // namespace com
}  // namespace aidl
