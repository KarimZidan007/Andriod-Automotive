#pragma once

#include "aidl/com/luxoft/gpio/IGpioService.h"

#include <android/binder_ibinder.h>

namespace aidl {
namespace com {
namespace luxoft {
namespace gpio {
class BnGpioService : public ::ndk::BnCInterface<IGpioService> {
public:
  BnGpioService();
  virtual ~BnGpioService();
protected:
  ::ndk::SpAIBinder createBinder() override;
private:
};
}  // namespace gpio
}  // namespace luxoft
}  // namespace com
}  // namespace aidl
