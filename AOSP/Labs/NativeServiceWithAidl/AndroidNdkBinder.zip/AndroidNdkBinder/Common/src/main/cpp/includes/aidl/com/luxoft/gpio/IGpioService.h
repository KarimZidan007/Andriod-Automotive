#pragma once

#include <android/binder_interface_utils.h>

#include <android/binder_parcel_utils.h>

namespace aidl {
namespace com {
namespace luxoft {
namespace gpio {
class IGpioService : public ::ndk::ICInterface {
public:
  static const char* descriptor;
  IGpioService();
  virtual ~IGpioService();



  static std::shared_ptr<IGpioService> fromBinder(const ::ndk::SpAIBinder& binder);
  static binder_status_t writeToParcel(AParcel* parcel, const std::shared_ptr<IGpioService>& instance);
  static binder_status_t readFromParcel(const AParcel* parcel, std::shared_ptr<IGpioService>* instance);
  static bool setDefaultImpl(std::shared_ptr<IGpioService> impl);
  static const std::shared_ptr<IGpioService>& getDefaultImpl();
  virtual ::ndk::ScopedAStatus setGpioState(int32_t in_pin, bool in_value, bool* _aidl_return) = 0;
  virtual ::ndk::ScopedAStatus getGpioState(int32_t in_pin, bool* _aidl_return) = 0;
private:
  static std::shared_ptr<IGpioService> default_impl;
};
class IGpioServiceDefault : public IGpioService {
public:
  ::ndk::ScopedAStatus setGpioState(int32_t in_pin, bool in_value, bool* _aidl_return) override;
  ::ndk::ScopedAStatus getGpioState(int32_t in_pin, bool* _aidl_return) override;
  ::ndk::SpAIBinder asBinder() override;
  bool isRemote() override;
};
}  // namespace gpio
}  // namespace luxoft
}  // namespace com
}  // namespace aidl
